export default function LoginPage() {
  return <div>Login Page Coming Soon</div>;
}