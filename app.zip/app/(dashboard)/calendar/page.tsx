export default function LoginPage() {
  return <div>Calendar Coming Soon</div>;
}